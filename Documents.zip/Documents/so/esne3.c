#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>

#define MAX_SIZE 10
int fd;    int count;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

/*void push(int fd, int toPush) {
	int size;
	read(fd, size, sizeof(int));	// Giudicare se e' meglio fare read() della size nel main()
	write(fd+size, toPush, sizeof(int));
	write(fd, size+1, sizeof(int));
}

int pop(int fd) {
	int read_record;
	read(fd+size-1, read_record, sizeof(int));
	write(fd, size-1, sizeof(int));
	return read_record;
}*/

void f_push(int v) {
	lseek(fd,(count+1)*sizeof(int),SEEK_SET);
	write(fd,&v,sizeof(int));
	count++;
	lseek(fd,0,SEEK_SET);
	write(fd,&count,sizeof(int));
}

int f_pop() {
	int zero=0;
	int ret;
	lseek(fd,count*sizeof(int),SEEK_SET);
	read(fd, &ret, sizeof(int));
	lseek(fd,count*sizeof(int),SEEK_SET);
	write(fd, &zero, sizeof(int));
	count--;
	lseek(fd,0,SEEK_SET);
	write(fd,&count,sizeof(int));
	return ret;
}

void* producer(void* arg) {
	while(1) {
		long sleep_time = random() % 1000000;	// Per un milione di microsecondi
		usleep(sleep_time);
		pthread_mutex_lock(&mutex);
		while (count == MAX_SIZE)
			pthread_cond_wait(&cond, &mutex);
		long elements = random() % (MAX_SIZE - count);
		for (int i=0; i<elements; i++) {
			int toPush = (int)random();
			f_push(toPush);
			printf("Producer: buffer[%d]=%d\n", count, toPush);
		}
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
	}
	return NULL;
}

void* consumer(void* arg) {
	while (1) {
		long sleep_time = random() % 1000000;
		usleep(sleep_time);
		pthread_mutex_lock(&mutex);
		while (count == 0)
			pthread_cond_wait(&cond, &mutex);
		long elements = random() % count;
		for (int i=0; i<elements; i++) {
			printf("Consumer: buffer[%d]=%d\n", count+1, f_pop());
		}
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
	}
	return NULL;
}

void stampa_file() {
	int fd = open("file",  O_RDONLY);
	int buf;
	for(int i=0; i<MAX_SIZE+1; i++) {
		read(fd, &buf, sizeof(int));
		if(i%11 == 0)
			printf("\n[%d]\t", buf);
		else
			printf("%d\t", buf);
	}
	printf("\n");
	close(fd);
}

int main(int argc, char** argv) {
	if(argc > 1) {
		stampaFile();
		exit(EXIT_SUCCESS);
	}
	fd = open("file", O_CREAT|O_RDWR|O_TRUNC, S_IRUSR|S_IWUSR);
	int buf = 0;
	for(int i=0; i<MAX_SIZE+1; i++) {
		write(fd, &buf, sizeof(int));	// Scrive nel file uno zero di indice e dieci di dati
	}
	pthread_t producer_t, consumer_t;
	pthread_create(&producer_t, NULL, producer, NULL);
	pthread_create(&consumer_t, NULL, consumer, NULL);
	pthread_join(producer_t, NULL);
	pthread_join(consumer_t, NULL);
	return close(fd);
}


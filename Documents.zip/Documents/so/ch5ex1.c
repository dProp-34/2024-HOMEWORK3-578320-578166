#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
	int x = 100;
	printf("%d says: The variable x contains %d\n", (int) getpid(), x);
	int rc = fork();  // the variable has been copied into the child process
	if (rc < 0) printf("fork failed\n");
	else {
		printf("%d says: The variable x now contains %d\n", (int) getpid(), x);
		x = 50;   // the variable has now changed in both processes
		printf("%d says: The variable x now contains %d\n", (int) getpid(), x);
	}
}


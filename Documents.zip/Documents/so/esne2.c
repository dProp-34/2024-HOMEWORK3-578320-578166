#include <stdio.h>
#include <pthread.h>

void* myFunc(void* arg) {
	printf("funzione: %s\n", (char*)arg);
	return NULL;
}

int main() {
	pthread_t t1, t2;
	printf("main: begin\n");
	pthread_create(&t1, NULL, myFunc, "A");  //Stiamo creando un thread che esegua la nostra funzione con argomento "A"
	pthread_create(&t2, NULL, myFunc, "B");
	//Join fa si che il main termini solo dopo i nostri thread
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	printf("main: end\n");
	return 0;
}

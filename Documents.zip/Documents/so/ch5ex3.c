#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
	int rc = fork();
	if (rc < 0)  printf("fork failed\n");
	else if (rc == 0)  printf("%d says: Hello.\n", (int) getpid());
	else if (rc > 0)  printf("%d says: Goodbye.\n", (int) getpid());
}

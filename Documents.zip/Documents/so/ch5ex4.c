#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
	int rc = fork();
	if (rc < 0) printf("fork failed\n");
	else {
		char* myargs[3];
		myargs[0] = strdup("/bin/ls");
		myargs[1] = strdup("/");
		myargs[2] = NULL;  // To mark array end
		printf("%d says: I'm about to execute ls.\n", (int) getpid());
		execv(myargs[0], myargs);  // Note that exec terminates the program
		printf("%d says: This shouldn't print out.\n", (int) getpid());
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#define N_RECORDS 10

struct record {
	int a;  int b;  int c;
};

int compara(const void* x, const void* y) {
	struct record* one = (struct record*) x;
	struct record* two = (struct record*) y;
	return one->a - two->a;  // To define the ordering relationship as 'lesser than'
}

struct record* genera(int n) {
	struct record* myRecords = (struct record*) calloc(n, sizeof(struct record));
	for(int i=0; i<n; i++) {
		myRecords[i].a = rand();
		myRecords[i].b = rand();
		myRecords[i].c = rand();
	}
	return myRecords;
}

void scrivi(char* path, struct record* myRecords, int n) {
	int fd = open(path, O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU);  // S_IRWXU lets file owner have read, write, and execute permission
	if(fd == -1) {
		perror("Apertura non riuscita: ");
		exit(1);
	}
	for (int i=0; i<n; i++) {
		int scritto = 0;
		while (scritto < sizeof(struct record)) {
			scritto += write(fd, (char*)&myRecords[i]+scritto, sizeof(struct record)-scritto);  // Third argument specifies bytes to write, in this case starting from 12
		}
	}
	close(fd);
}

struct record* leggi(char* path) {
	int fd = open(path, O_RDONLY);
	if(fd == -1) {
		perror("Apertura non riuscita: ");
		exit(1);
	}
	struct stat myStats;
	fstat(fd, &myStats);  // Defines a series of statistics on the file
	struct record* myRecords = (struct record*) malloc(myStats.st_size);  // Al posto di sizeof'' * n
	int n_records = myStats.st_size / sizeof(struct record);
	for(int i=0; i<n_records; i++) {
		read(fd, myRecords, myStats.st_size);
	}
	close(fd);
	return myRecords;
}

void stampa_record(struct record* myRecords, int n) {
	printf("\n\n");
	for(int i=0; i<n; i++) {
		printf("%d) Contiene\t%d\t%d\t%d.\n", i, myRecords[i].a, myRecords[i].b, myRecords[i].c);  // \t e' la TAB
	}
}

int main(int argc, char** argv) {
	if(argc != 2) {
		fprintf(stderr, "Devi passare un argomento.\n");
		exit(1);
	}
	char* path = argv[1];

	struct record* myRecords = genera(N_RECORDS);
	stampa_record(myRecords, N_RECORDS);
	scrivi(path, myRecords, N_RECORDS);
	free(myRecords);
	myRecords=leggi(path);
	stampa_record(myRecords, N_RECORDS);
	qsort(myRecords, N_RECORDS, sizeof(struct record), compara);
	stampa_record(myRecords, N_RECORDS);
}
